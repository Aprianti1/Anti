<html>
<head><?php echo $map['js']; ?></head>
<body>
  <script async defer src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDj-hFGBMNwgXz91WdQn5O1N6mgxKJcX1U&callback=initMap"></script>

  <?php echo $map['html']; ?>
  
</body>
</html>